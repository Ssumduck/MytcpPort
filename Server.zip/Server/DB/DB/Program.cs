﻿using System;
using MySql.Data;
using System.Net.Sockets;
using System.IO;
using System.Net;
using System.Threading;
using System.Collections.Generic;
using DB;

namespace DB
{
    class Program
    {
        static void Main(string[] args)
        {
            LoginServer login = new LoginServer("49.163.25.60", 1666);
            DataServer data = new DataServer("49.163.25.60", 1667);
            ChatServer chat = new ChatServer("49.163.25.60", 1668);
            chat.CreateSocket();
            data.CreateSocket();
            login.CreateSocket();
            Thread loginthread = new Thread(() => login.LoginServerWait());
            loginthread.Start();
            Thread datathread = new Thread(() => data.DataServerWait());
            datathread.Start();
            Thread chatthread = new Thread(() => chat.ChatServerWait());
            chatthread.Start();

            Console.ReadLine();
        }

        public static Socket Accept(Socket server)
        {
            Socket socket = server.Accept();

            return socket;
        }
    }

}

